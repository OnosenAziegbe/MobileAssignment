package com.example.locationpinned;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private LocationDatabaseHelper databaseHelper;
    private LocationHelper locationHelper;
    private EditText addressEditText, latitudeEditText, longitudeEditText;
    private Button addButton, queryButton, updateButton, deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new LocationDatabaseHelper(this);
        locationHelper = new LocationHelper();

        addressEditText = findViewById(R.id.addressEditText);
        latitudeEditText = findViewById(R.id.latitudeEditText);
        longitudeEditText = findViewById(R.id.longitudeEditText);

        addButton = findViewById(R.id.addButton);
        queryButton = findViewById(R.id.queryButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                double latitude = Double.parseDouble(latitudeEditText.getText().toString());
                double longitude = Double.parseDouble(longitudeEditText.getText().toString());

                // Convert latitude and longitude to address
                String address = locationHelper.getAddressFromLatLng(MainActivity.this, latitude, longitude);

                // Now you have the address, you can add it to the database and perform other operations
                databaseHelper.addLocation(address, latitude, longitude);
                clearFields();
            }
        });

       queryButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String address = addressEditText.getText().toString();
                Cursor cursor = databaseHelper.getLocation(address);
                if (cursor.moveToFirst()) {
                    latitudeEditText.setText(String.valueOf(cursor.getDouble(cursor.getColumnIndex("latitude"))));
                    longitudeEditText.setText(String.valueOf(cursor.getDouble(cursor.getColumnIndex("longitude"))));
                } else {
                    clearFields();
                }
                cursor.close();
            }
        });

        updateButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String address = addressEditText.getText().toString();
                double latitude = Double.parseDouble(latitudeEditText.getText().toString());
                double longitude = Double.parseDouble(longitudeEditText.getText().toString());

                // Get the ID of the location to be updated from the database
                Cursor cursor = databaseHelper.getLocation(address);
                int id = -1;
                if (cursor.moveToFirst()) {
                    id = cursor.getInt(cursor.getColumnIndex("id"));
                }
                cursor.close();

                if (id != -1) {
                    databaseHelper.updateLocation(id, address, latitude, longitude);
                    clearFields();
                    showToast("Location updated successfully");
                } else {
                    showToast("Location not found");
                }
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                final String address = addressEditText.getText().toString();

                // Get the ID of the location to be deleted from the database
                Cursor cursor = databaseHelper.getLocation(address);
                int id = -1;
                if (cursor.moveToFirst()) {
                    id = cursor.getInt(cursor.getColumnIndex("id"));
                }
                cursor.close();

                if (id != -1) {
                    int finalId = id;
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("Delete Location")
                            .setMessage("Are you sure you want to delete this location?")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    databaseHelper.deleteLocation(finalId);
                                    clearFields();
                                    showToast("Location deleted successfully");
                                }
                            })
                            .setNegativeButton(android.R.string.no, null)
                            .show();
                } else {
                    showToast("Location not found");
                }
            }
        });
    }

    private void clearFields() {
        addressEditText.setText("");
        latitudeEditText.setText("");
        longitudeEditText.setText("");
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}

