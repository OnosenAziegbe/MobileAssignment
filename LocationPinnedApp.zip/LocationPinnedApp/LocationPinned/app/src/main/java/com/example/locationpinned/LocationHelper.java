package com.example.locationpinned;

import android.content.Context;
import android.content.res.AssetManager;
import android.location.Address;
import android.location.Geocoder;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LocationHelper {

    public List<String> readLocationsFromAssets(Context context) {
        List<String> locations = new ArrayList<>();

        AssetManager assetManager = context.getAssets();
        try {
            InputStream inputStream = context.getResources().openRawResource(R.raw.locations);

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                locations.add(line);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return locations;
    }

    public String getAddressFromLatLng(Context context, double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        String addressString = "";

        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && addresses.size() > 0) {
                Address address = addresses.get(0);
                StringBuilder addressStringBuilder = new StringBuilder();

                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    addressStringBuilder.append(address.getAddressLine(i)).append(" ");
                }

                addressString = addressStringBuilder.toString().trim();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return addressString;
    }
}
